/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dye.micheal.domain;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author Administrator
 */
public class Stock {

    String companyName;
    String stockSymbol;
    int currentPrice;//specification says int but shares will likely go into decimal
    int numberOfSharesOutstanding;

    public Stock(String companyName, String stockSymbol, int currentPrice, int SharesOutstanding) {
        this.companyName = companyName;
        this.stockSymbol = stockSymbol;
        this.currentPrice = currentPrice;
        this.numberOfSharesOutstanding = SharesOutstanding;
    }
    

    public String getCompanyName() {
        return companyName;
    }

    public String getStockSymbol() {
        return stockSymbol;
    }

    public int getCurrentPrice() {
        return currentPrice;
    }

    public int getNumberOfSharesOutstand() {
        return numberOfSharesOutstanding;
    }

    @Override
    public String toString() {
        return companyName + "," + stockSymbol + "," + currentPrice + "," + numberOfSharesOutstanding;
    }

}
