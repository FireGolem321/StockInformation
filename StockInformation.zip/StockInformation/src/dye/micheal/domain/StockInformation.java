/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dye.micheal.domain;

import dye.micheal.interfaces.StockWebService;
import java.util.regex.Pattern;
import javax.jws.WebService;
import javax.security.sasl.AuthenticationException;

/**
 *
 * @author Administrator
 */
public class StockInformation {

    private String stockSymbol;
    private boolean available;
    private String companyName;
    private int currentPrice;
    private int numberOfSharesOutstanding;//int is faster and will do the job just as fine
    private int marketCapitilisationInMillions;
    private int userID;//under 10,000 userID's so having int makes more sense and it is also faster
    private String password;
    private String stockData;

    public StockInformation(StockWebService webService, int userID, String password, String symbol) {

        if (validId(userID) && validPassword(password)) {
            this.userID = userID;
            this.password = password;
            this.stockSymbol = symbol;
            boolean loggedIn = webService.authenticate(userID, password);

            if (loggedIn) {
                stockData = webService.getStockInfo(symbol);
                process(stockData);
            }
        }

    }

    public String getStockSymbol() {
        return stockSymbol;
    }

    private void setStockSymbol(String stockSymbol) {
        this.stockSymbol = stockSymbol;
    }

    public boolean getAvailable() {
        return available;
    }

    private void setAvailable(boolean available) {
        this.available = available;
    }

    public String getCompanyName() {
        return companyName;
    }

    private void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getCurrentPrice() {
        return currentPrice;
    }

    private void setCurrentPrice(int currentPrice) {
        this.currentPrice = currentPrice;
    }

    public int getNumberOfSharesOutstanding() {
        return numberOfSharesOutstanding;
    }

    private void setNumberOfSharesOutstanding(int numberOfSharesOutstanding) {
        this.numberOfSharesOutstanding = numberOfSharesOutstanding;
    }

    public int getMarketCapitilisationInMillions() {
        return marketCapitilisationInMillions;
    }

    private void setMarketCapitilisationInMillions(int marketCapitilisationInMillions) {
        this.marketCapitilisationInMillions = marketCapitilisationInMillions;
    }

    @Override
    public String toString() {
        return "StockInformation" + "companyName=" + companyName + "| stockSymbol" + stockSymbol + "| currentPrice=" + currentPrice;
    }

    private boolean validPassword(String password) {
         boolean matched = false;
        if(password!=null && password.length()>=8){
            Pattern pattern = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^aA-zZ0-9]).{8,})");            
            matched  = pattern.matcher(password).matches();
        }
        return matched;
    }

    private boolean validId(int userID) {
        return (userID >= 1 && userID <= 9999);
    }

    private void process(String stockData) {
        if (stockData != null) {
            String[] data = stockData.split(",");
            setCompanyName(data[0]);
            setStockSymbol(data[1]);
            setCurrentPrice(Integer.parseInt(data[2]));
            setNumberOfSharesOutstanding(Integer.parseInt(data[3]));
        }
    }
}
