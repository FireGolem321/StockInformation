/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dye.micheal.interfaces;
import dye.micheal.domain.StockInformation;
/**
 *
 * @author Administrator
 */
public interface StockWebService {   
    public boolean authenticate(int userID, String password);
    public String getStockInfo (String symbol);
    
    
}
