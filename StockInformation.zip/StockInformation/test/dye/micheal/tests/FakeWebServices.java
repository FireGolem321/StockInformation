/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dye.micheal.tests;

import dye.micheal.domain.Stock;
import dye.micheal.interfaces.StockWebService;
import dye.micheal.tests.StockInformationTest;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class FakeWebServices implements StockWebService {
    
    int userID = 4201;
    String password = "Pa$$w0rd";
    
    public FakeWebServices() {
    }

    @Override
    public boolean authenticate(int userID, String password) {
        if(this.userID == userID && this.password.equals(password))
            return true;
        else return false;         
    }
    
    @Override
    public String getStockInfo(String symbol) {
        return getStockInfo().get(symbol).toString();
    }

    private Dictionary<String, Stock> getStockInfo(){
        Dictionary myStock  = new Hashtable<>();
        myStock.put("MVL", new Stock("Marvel","MVL", 1550, 293283));
        myStock.put("MCD", new Stock("McDonalds","MCD",  18305, 293810));
        return myStock;
    }
}
