/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dye.micheal.tests;

import dye.micheal.domain.StockInformation;
import dye.micheal.interfaces.StockWebService;
import dye.micheal.tests.FakeWebServices;
import javax.jws.WebService;
import jdk.nashorn.internal.objects.annotations.Setter;
import junit.framework.AssertionFailedError;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class StockInformationTest {

    int userID = 4201;
    String password = "Pa$$w0rd";
    StockWebService webService;
    public StockInformationTest() {

    }

    @Before
    public void testInitialize() {
        webService = new FakeWebServices();
    }

    @Test
    public void testLogin() {//this test is for when the userid and password match what they are expected to be granting access
        //Arrange
        int expectedUserID = 4201;
        String expectedPassword = "Pa$$w0rd";
        //Act
        int actualUserID = userID;
        String actualPassword = password;
        //Assert
        assertEquals(expectedUserID, actualUserID);
        assertEquals(expectedPassword, actualPassword);
    }

    @Test(expected = AssertionError.class)
    public void testLoginFail() {// this test is for when the expected details don't match the actual details
        int expectedUserID = 6969;
        String expectedPassword = "Bl0nke!s";
        //Act
        int actualUserID = userID;
        String actualPassword = password;
        //Assert
        assertEquals(expectedUserID, actualUserID);
        assertEquals(expectedPassword, actualPassword);
    }

    @Test(expected = AssertionError.class)
    public void testInvalidUserID() {//this test is for when the UserID is out of the expected 1-9999 range
        //Arrange
        int userID2 = 99999;
        int expectedUserID = 4201;
        String expectedPassword = "Pa$$w0rd";
        //Act
        int actualUserID = userID2;
        String actualPassword = password;
        //Assert
        assertEquals(expectedUserID, actualUserID);
        assertEquals(expectedPassword, actualPassword);
    }

    @Test(expected = AssertionError.class)
    public void testInvalidPassword() {//this test is for when the Password doesn't match the requirements of a password
        //Arrange
        int expectedUserID = 4201;
        String password2 = "Password";
        String expectedPassword = "Pa$$w0rd";
        //Act
        int actualUserID = userID;
        String actualPassword = password2;
        //Assert
        assertEquals(expectedUserID, actualUserID);
        assertEquals(expectedPassword, actualPassword);
    }

    @Test
    public void testGetStockInformation() {//This test is designed for me to be able to get a companyName back
        //Arrange 
        StockInformation stockInfo = new StockInformation(webService, userID, password, "MVL");
        String expectedCompanyName = "Marvel";
        //Act
        String actualCompanyName = stockInfo.getCompanyName();
        assertTrue(expectedCompanyName.equalsIgnoreCase(actualCompanyName));
    }

    @Test
    public void testGetAllDataForSingleStock() {//This test is to grab all information in stockInfo
        //Arrange
        StockInformation stockInfo = new StockInformation(webService, userID, password, "MCD");
        String expectedCompanyName = "McDonalds";
        String expectedStockSymbol = "MCD";
        int expectedCurrentPrice = (int) 183.59;
        int expectedNumberOfSharesOutstanding = 293810;
        //Act
        String actualCompanyName = stockInfo.getCompanyName();
        String actualStockSymbol = stockInfo.getStockSymbol();
        int actualCurrentPrice = stockInfo.getCurrentPrice();
        int actualNumberOfSharesOutstanding = stockInfo.getNumberOfSharesOutstanding();
        //Assert
        assertTrue(expectedCompanyName.equalsIgnoreCase(actualCompanyName));
        assertTrue(expectedStockSymbol.equalsIgnoreCase(actualStockSymbol));
        assertEquals(expectedCurrentPrice, (actualCurrentPrice/100), 1e-2);
        assertEquals(expectedNumberOfSharesOutstanding, (actualNumberOfSharesOutstanding));
    }

    @Test(expected = NullPointerException.class)
    public void testSearchForInvalidData() {//this test is to see what happens when searching for an invalid stock
        StockInformation stockInfo = new StockInformation(webService, userID, password, "DIX");
        String expectedCompanyName = "Dixons";
        //Act
        String actualCompanyName = stockInfo.getCompanyName();
        assertTrue(expectedCompanyName.equalsIgnoreCase(actualCompanyName));
    }
    
    @Test
    public void testMarketCapitilisationInMillions() {//this test is designed to confirm when the actual market capitilisation is millions matches the expected
        StockInformation stockInfo = new StockInformation(webService, userID, password, "MVL");
        int expectedMarketCapitilisationInMillions = 4545886;
        //Act
        int actualCurrentPrice = stockInfo.getCurrentPrice();
        int actualNumberOfSharesOutstanding = stockInfo.getNumberOfSharesOutstanding();
        int actualMarketCapitilisationInMillions = ((int)actualNumberOfSharesOutstanding * actualCurrentPrice)/100;
        //Assert
        assertEquals(expectedMarketCapitilisationInMillions, (actualMarketCapitilisationInMillions));
    }
    
    @Test(expected = AssertionError.class)
    public void testMarketCapitilisationInMillionsFail() {//this test is for when the expected and actual don't work
        StockInformation stockInfo = new StockInformation(webService, userID, password, "MVL");
        int expectedMarketCapitilisationInMillions = 29183912;
        //Act
        int actualCurrentPrice = stockInfo.getCurrentPrice();
        int actualNumberOfSharesOutstanding = stockInfo.getNumberOfSharesOutstanding();
        int actualMarketCapitilisationInMillions = ((int)actualNumberOfSharesOutstanding * actualCurrentPrice)/100;
        //Assert
        assertEquals(expectedMarketCapitilisationInMillions, (actualMarketCapitilisationInMillions));
    }    
}
